from flask import Flask, render_template,jsonify,request

app = Flask('app')

@app.route('/')
def hello_world():
  return render_template("index.html")
@app.route('/generate', methods=['GET', 'POST'])
def generate():
  if request.method == 'POST':
    prompt = request.json.get('prompt')
    print(prompt)
    output="hey adarsh"
    return output

app.run(host='0.0.0.0', port=8080)
